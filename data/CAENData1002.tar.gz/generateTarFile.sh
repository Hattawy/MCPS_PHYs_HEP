#!/bin/bash

tar -czf CAENData1002.tar.gz TR*.dat wave_[0135].dat runDescription.txt WaveDumpConfig.txt *.sh

tar -vtzf CAENData1002.tar.gz


