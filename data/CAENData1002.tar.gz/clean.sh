#!/bin/bash

/bin/rm -f TR_0_0.txt TR_0_1.txt
/bin/rm -f wave_[0123456789].txt
/bin/rm -f wave_1[012345].txt

/bin/rm -f TR_0_0.dat TR_0_1.dat
/bin/rm -f wave_[0123456789].dat
/bin/rm -f wave_1[012345].dat
