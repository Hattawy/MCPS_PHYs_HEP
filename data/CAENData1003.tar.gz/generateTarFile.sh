#!/bin/bash

RUN=1003

tar -czf CAENData$RUN.tar.gz TR*.dat wave_[0135].dat runDescription.txt WaveDumpConfig.txt *.sh

tar -vtzf CAENData$RUN.tar.gz


