#!/bin/bash

tar -czf CAENData1001.tar.gz TR*.dat wave_[0135].dat runDescription.txt WaveDumpConfig.txt *.sh

tar -vtzf CAENData1001.tar.gz


