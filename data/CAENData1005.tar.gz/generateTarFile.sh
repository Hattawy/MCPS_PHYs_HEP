#!/bin/bash

RUN=1005

#tar -czf CAENData$RUN.tar.gz TR*.dat wave_[0135].dat runDescription.txt WaveDumpConfig.txt *.sh
tar -czf CAENData$RUN.tar.gz TR*.dat wave_[0247].dat runDescription.txt WaveDumpConfig.txt *.sh

tar -vtzf CAENData$RUN.tar.gz


