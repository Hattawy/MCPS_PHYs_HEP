#!/bin/bash

RUN=1004

tar -czf CAENData$RUN.tar.gz TR*.dat wave_[0135].dat runDescription.txt WaveDumpConfig.txt *.sh

tar -vtzf CAENData$RUN.tar.gz


